<?php $__env->startSection('title', translate('Transfer List')); ?>

<?php $__env->startPush('css_or_js'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content container-fluid">
        <!-- Page Header -->
        <div class="page-header">
            <div class="row align-items-center">
                <div class="col-sm mb-2 mb-sm-0 flex-between">
                    <h1 class="page-header-title"><?php echo e(translate('Transfer')); ?></h1>
                    <h1><i class="tio-user-switch"></i></h1>
                </div>
            </div>
        </div>
        <!-- End Page Header -->
        <div class="row gx-2 gx-lg-3">
            <div class="col-sm-12 col-lg-12 mb-3 mb-lg-2 card card-body mx-3">
                <form action="<?php echo e(route('admin.transfer.store')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row">











                        <div class="col-md-4 col-12">
                            <div class="form-group">
                                <label class="input-label"
                                       for="exampleFormControlInput1"><?php echo e(translate('Receiver Type')); ?></label>
                                <select name="receiver_type" class="form-control js-select2-custom" id="receiver_type"
                                        required>
                                    <option value="" selected
                                            disabled><?php echo e(translate('Select Type')); ?></option>
                                    <option value="1"><?php echo e(translate('Agent')); ?></option>
                                    <option value="2"><?php echo e(translate('Customer')); ?></option>
                                </select>
                            </div>
                        </div>

                        <div class="col-md-4 col-12">
                            <div class="form-group">
                                <label class="input-label"
                                       for="exampleFormControlInput1"><?php echo e(translate('Receiver')); ?></label>

                                <select name="to_user_id" class="form-control js-data-example-ajax" id="receiver"
                                        data-placeholder="<?php echo e(translate('Choose')); ?>"
                                        required>
                                </select>
                            </div>
                        </div>

                        <div class="col-md-4 col-12">
                            <div class="form-group">
                                <label class="input-label"
                                       for="exampleFormControlInput1"><?php echo e(translate('Amount')); ?></label>
                                <input type="number" name="amount" class="form-control" min="1" max="<?php echo e($unused_balance); ?>"
                                       placeholder="<?php echo e(translate('Ex : 9999')); ?>"
                                       required>
                                <?php if($unused_balance > 0): ?>
                                    <small class="w-100"><?php echo e(translate('The amount must be less than or equal to ') . $unused_balance); ?></small>
                                <?php else: ?>
                                    <small class="w-100"><?php echo e(translate('The amount is too low to transfer')); ?></small>
                                <?php endif; ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    <button type="submit"
                            class="btn btn-primary"><?php echo e(translate('Transfer')); ?></button>
                </form>
            </div>

            <div class="col-sm-12 col-lg-12 mb-3 mb-lg-2 mt-2">
                <div class="card">
                    <div class="card-header">
                        <div class="flex-start">
                            <h5 class="card-header-title"><?php echo e(translate('Transfer Table')); ?></h5>
                            <h5 class="card-header-title text-primary mx-1">(<?php echo e($transfers->total()); ?>)</h5>
                        </div>
                        <div>
                            <form action="<?php echo e(url()->current()); ?>" method="GET">
                                <div class="input-group">
                                    <input id="datatableSearch_" type="search" name="search"
                                           class="form-control"
                                           placeholder="<?php echo e(translate('Search')); ?>" aria-label="Search"
                                           value="<?php echo e($search); ?>" required autocomplete="off">
                                    <div class="input-group-append">
                                        <button type="submit" class="input-group-text"><i class="tio-search"></i>
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <!-- Table -->
                    <div class="table-responsive datatable-custom">
                        <table
                            class="table table-borderless table-thead-bordered table-nowrap table-align-middle card-table">
                            <thead class="thead-light">
                            <tr>
                                <th><?php echo e(translate('No#')); ?></th>
                                <th><?php echo e(translate('Receiver')); ?></th>
                                <th><?php echo e(translate('Receiver Type')); ?></th>
                                <th><?php echo e(translate('amount')); ?></th>
                                <th><?php echo e(translate('Time')); ?></th>
                            </tr>
                            </thead>

                            <tbody>
                            <?php $__currentLoopData = $transfers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$transfer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <?php echo e($transfers->firstitem()+$key); ?>

                                    </td>
                                    <td>
                                        <?php ($user_info = \App\CentralLogics\Helpers::get_user_info($transfer->receiver)); ?>
                                        <?php if(isset($user_info)): ?>
                                            <a href="<?php echo e(route('admin.customer.view',[$user_info['id']])); ?>"><?php echo e($user_info->f_name . ' ' . $user_info->l_name); ?></a>
                                        <?php else: ?>
                                            <span class="text-muted badge badge-danger text-dark"><?php echo e(translate('User unavailable')); ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($transfer->receiver_type == 1): ?>
                                            <span class="text-uppercase badge badge-light text-muted"><?php echo e(translate('Agent')); ?></span>
                                        <?php elseif($transfer->receiver_type == 2): ?>
                                            <span class="text-uppercase badge badge-light text-muted"><?php echo e(translate('Customer')); ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="amount-column">
                                        <span class="">
                                            <?php echo e(Helpers::set_symbol($transfer['amount'])); ?>

                                        </span>
                                    </td>
                                    <td>
                                        <span class="text-muted badge badge-light"><?php echo e($transfer->created_at->diffForHumans()); ?></span>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                        <hr>
                        <table>
                            <tfoot>
                            <?php echo $transfers->links(); ?>

                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
            <!-- End Table -->
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script_2'); ?>
    <script>
        $("#receiver").select2({
            ajax: {
                url: '<?php echo e(route('admin.transfer.get_user')); ?>',
                type: "get",
                data: function (params) {
                    var receiver_type = $('#receiver_type').val();
                    if (receiver_type == null) {
                        swal('<?php echo e(translate('Select_valid_receiver_type_first')); ?>');
                    }
                    // console.log("type: " + receiver_type);
                    return {
                        q: params.term, // search term
                        page: params.page,
                        receiver_type: receiver_type
                    };

                },
                processResults: function (data) {
                    // console.log("data: " + data);
                    return {
                        results: data
                    };
                },
                __port: function (params, success, failure) {
                    var $request = $.ajax(params);

                    $request.then(success);
                    $request.fail(failure);

                    return $request;
                }
            }
        });

        $('#receiver_type').on('change', function() {
            $('#receiver').empty();
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/czmcdcfryly0/public_html/rbpessacash.com/resources/views/admin-views/transfer/index.blade.php ENDPATH**/ ?>