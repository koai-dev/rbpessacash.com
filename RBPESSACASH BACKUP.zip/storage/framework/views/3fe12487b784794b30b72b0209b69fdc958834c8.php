<?php $__env->startSection('title', translate('Linked Website')); ?>

<?php $__env->startPush('css_or_js'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content container-fluid">
        <!-- Page Header -->
        <div class="page-header">
            <div class="row align-items-center">
                <div class="col-sm mb-2 mb-sm-0">
                    <h1 class="page-header-title"><i
                            class="tio-add-circle-outlined"></i> <?php echo e(translate('Add New Website')); ?>

                    </h1>
                </div>
            </div>
        </div>
        <!-- End Page Header -->
        <div class="row gx-2 gx-lg-3">
            <div class="col-sm-12 col-lg-12 mb-3 mb-lg-2 card card-body mx-3">
                <form action="<?php echo e(route('admin.linked-website')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-6">
                            <div class="form-group">
                                <label class="input-label"
                                       for="exampleFormControlInput1"><?php echo e(translate('name')); ?></label>
                                <input type="text" name="name" class="form-control"
                                       placeholder="<?php echo e(translate('example')); ?>" required>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label class="input-label"
                                       for="exampleFormControlInput1"><?php echo e(translate('URL')); ?></label>
                                <input type="text" name="url" class="form-control"
                                       placeholder="<?php echo e(translate('""_www.example.com')); ?>" required>
                            </div>
                        </div>

                        <div class="form-group col-12">
                            <label class="text-dark"><?php echo e(translate('image')); ?></label><small style="color: red">*
                                ( <?php echo e(translate('ratio 1:1')); ?> )</small>
                            <div class="custom-file">
                                <input type="file" name="image" id="customFileEg1" class="custom-file-input"
                                       accept=".jpg, .png, .jpeg, .gif, .bmp, .tif, .tiff|image/*" required>
                                <label class="custom-file-label"
                                       for="customFileEg1"><?php echo e(translate('choose')); ?> <?php echo e(translate('file')); ?></label>
                            </div>
                            <center class="mt-4">
                                <img style="height: 200px;border: 1px solid; border-radius: 10px;" id="viewer"
                                     src="<?php echo e(asset('public/assets/admin/img/400x400/img2.jpg')); ?>"
                                     alt="delivery-man image"/>
                            </center>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary"><?php echo e(translate('submit')); ?></button>
                </form>
            </div>

            <div class="col-sm-12 col-lg-12 mb-3 mb-lg-2 mt-2">
                <div class="card">
                    <div class="card-header ml-3">
                        <div class="row">
                            <div class="">
                                <h5><?php echo e(translate('Linked Website Table')); ?>

                                    <span class="text-primary">(<?php echo e($linked_websites->total()); ?>)</span>
                                </h5>
                            </div>
                        </div>
                    </div>
                    <!-- Table -->
                    <div class="table-responsive datatable-custom">
                        <table id="columnSearchDatatable"
                               class="table table-borderless table-thead-bordered table-nowrap table-align-middle card-table"
                               data-hs-datatables-options='{
                                 "order": [],
                                 "orderCellsTop": true
                               }'>
                            <thead class="thead-light">
                            <tr>
                                <th><?php echo e(translate('#')); ?></th>
                                <th style="width: 50%"><?php echo e(translate('name')); ?></th>
                                <th style="width: 50%"><?php echo e(translate('URL')); ?></th>
                                <th style="width: 50%"><?php echo e(translate('image')); ?></th>
                                <th style="width: 50%"><?php echo e(translate('Status')); ?></th>
                                <th style="width: 10%"><?php echo e(translate('action')); ?></th>
                            </tr>

                            </thead>

                            <tbody>
                            <?php $__currentLoopData = $linked_websites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$linked_website): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($linked_websites->firstItem()+$key); ?></td>
                                    <td>
                                        <span class="d-block font-size-sm text-body">
                                            <?php echo e($linked_website['name']); ?>

                                        </span>
                                    </td>
                                    <td><?php echo e($linked_website['url']); ?></td>
                                    <td>
                                        <div style="height: 60px; width: 60px;">
                                            <img class="shadow-image"
                                                src="<?php echo e(asset('storage/app/public/website')); ?>/<?php echo e($linked_website['image']); ?>"
                                                style="width: 100%;height: auto"
                                                onerror="this.src='<?php echo e(asset('public/assets/admin/img/160x160/img2.jpg')); ?>'">
                                        </div>
                                    </td>
                                    <td>
                                        <label class="toggle-switch d-flex align-items-center mb-3" for="welcome_status_<?php echo e($linked_website['id']); ?>">
                                            <input type="checkbox" name="welcome_status"
                                                   class="toggle-switch-input"
                                                   id="welcome_status_<?php echo e($linked_website['id']); ?>" <?php echo e($linked_website?($linked_website['status']==1?'checked':''):''); ?>

                                                   onclick="location.href='<?php echo e(route('admin.linked-website-status',[$linked_website['id']])); ?>'">

                                            <span class="toggle-switch-label p-1">
                                                <span class="toggle-switch-indicator"></span>
                                            </span>
                                        </label>
                                    </td>
                                    <td>
                                        <!-- Dropdown -->
                                        <div class="dropdown">
                                            <button class="btn btn-secondary dropdown-toggle" type="button"
                                                    id="dropdownMenuButton" data-toggle="dropdown"
                                                    aria-haspopup="true"
                                                    aria-expanded="false">
                                                <i class="tio-settings"></i>
                                            </button>
                                            <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                                <a class="dropdown-item"
                                                   href="<?php echo e(route('admin.linked-website-edit',[$linked_website['id']])); ?>"><?php echo e(translate('edit')); ?></a>

                                                <a class="dropdown-item"
                                                   href="<?php echo e(route('admin.linked-website-delete',['id'=>$linked_website['id']])); ?>"><?php echo e(translate('delete')); ?></a>
                                            </div>
                                        </div>
                                        <!-- End Dropdown -->
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <table>
                            <tfoot>
                            <?php echo $linked_websites->links(); ?>

                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
            <!-- End Table -->
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script_2'); ?>
    <script>
        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#viewer').attr('src', e.target.result);
                }

                reader.readAsDataURL(input.files[0]);
            }
        }

        $("#customFileEg1").change(function () {
            readURL(this);
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/czmcdcfryly0/public_html/rbpessacash.com/resources/views/admin-views/business-settings/linked-website.blade.php ENDPATH**/ ?>