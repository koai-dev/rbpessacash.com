<?php $__env->startSection('title', translate('Agent List')); ?>

<?php $__env->startPush('css_or_js'); ?>
    <script src="https://use.fontawesome.com/74721296a6.js"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content container-fluid">
        <!-- Page Header -->
        <div class="page-header">
            <div class="row align-items-center">
                <div class="col-sm mb-2 mb-sm-0">
                    <h1 class="page-header-title"><i
                            class="tio-filter-list"></i> <?php echo e(translate('Agent')); ?> <?php echo e(translate('list')); ?>

                    </h1>
                </div>
                <a href="<?php echo e(route('admin.agent.add')); ?>" class="btn btn-primary pull-right mr-3"><i
                        class="tio-add-circle"></i> <?php echo e(translate('Add')); ?> <?php echo e(translate('Agent')); ?>

                </a>
            </div>
        </div>
        <!-- End Page Header -->
        <div class="row gx-2 gx-lg-3">
            <div class="col-sm-12 col-lg-12 mb-3 mb-lg-2">
                <!-- Card -->
                <div class="card">
                    <!-- Header -->
                    <div class="card-header">
                        <div class="flex-start">
                            <h5 class="card-header-title"><?php echo e(translate('Agent Table')); ?></h5>
                            <h5 class="card-header-title text-primary mx-1">(<?php echo e($agents->total()); ?>)</h5>
                        </div>
                        <div>
                            <form action="<?php echo e(url()->current()); ?>" method="GET">
                                <div class="input-group">
                                    <input id="datatableSearch_" type="search" name="search"
                                           class="form-control"
                                           placeholder="<?php echo e(translate('Search')); ?>" aria-label="Search"
                                           value="<?php echo e($search); ?>" required autocomplete="off">
                                    <div class="input-group-append">
                                        <button type="submit" class="input-group-text"><i class="tio-search"></i>
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <!-- End Header -->

                    <!-- Table -->
                    <div class="table-responsive datatable-custom">
                        <table
                            class="table table-borderless table-thead-bordered table-nowrap table-align-middle card-table">
                            <thead class="thead-light">
                            <tr>
                                <th><?php echo e(translate('#NO')); ?></th>
                                <th style="width: 15%"><?php echo e(translate('image')); ?></th>
                                <th style="width: 30%"><?php echo e(translate('name')); ?></th>
                                <th><?php echo e(translate('phone')); ?></th>
                                <th><?php echo e(translate('email')); ?></th>
                                <th><?php echo e(translate('status')); ?></th>
                                <th><?php echo e(translate('action')); ?></th>
                            </tr>
                            </thead>

                            <tbody id="set-rows">
                            <?php $__currentLoopData = $agents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$agent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($agents->firstitem()+$key); ?></td>
                                    <td>
                                        <img class="rounded-circle" height="60px" width="60px" style="cursor: pointer"
                                             onclick="location.href='<?php echo e(route('admin.customer.view',[$agent['id']])); ?>'"
                                             onerror="this.src='<?php echo e(asset('public/assets/admin/img/160x160/img1.jpg')); ?>'"
                                             src="<?php echo e(asset('storage/app/public/agent')); ?>/<?php echo e($agent['image']); ?>">
                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('admin.agent.view',[$agent['id']])); ?>" class="d-block font-size-sm text-body">
                                            <?php echo e($agent['f_name'].' '.$agent['l_name']); ?>

                                        </a>
                                    </td>
                                    <td>
                                        <?php echo e($agent['phone']); ?>

                                    </td>
                                    <td>
                                        <?php if(isset($agent['email'])): ?>
                                            <a href="mailto:<?php echo e($agent['email']); ?>" class="text-primary"><?php echo e($agent['email']); ?></a>
                                        <?php else: ?>
                                            <span class="badge-pill badge-soft-dark text-muted">Email unavailable</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <label class="toggle-switch d-flex align-items-center mb-3" for="welcome_status_<?php echo e($agent['id']); ?>">
                                            <input type="checkbox" name="welcome_status"
                                                   class="toggle-switch-input"
                                                   id="welcome_status_<?php echo e($agent['id']); ?>" <?php echo e($agent?($agent['is_active']==1?'checked':''):''); ?>

                                                   onclick="location.href='<?php echo e(route('admin.agent.status',[$agent['id']])); ?>'">

                                            <span class="toggle-switch-label p-1">
                                                <span class="toggle-switch-indicator"></span>
                                            </span>
                                        </label>
                                    </td>
                                    <td>
                                        <a class="btn-sm btn-primary p-1 m-1"
                                           href="<?php echo e(route('admin.agent.view',[$agent['id']])); ?>">
                                            <i class="fa fa-eye pl-1" aria-hidden="true"></i>
                                        </a>
                                        <a class="btn-sm btn-secondary p-1 pr-2 m-1"
                                           href="<?php echo e(route('admin.agent.edit',[$agent['id']])); ?>">
                                            <i class="fa fa-pencil pl-1" aria-hidden="true"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                        <div class="page-area">
                            <table>
                                <tfoot>
                                <?php echo $agents->links(); ?>

                                </tfoot>
                            </table>
                        </div>

                    </div>
                    <!-- End Table -->
                </div>
                <!-- End Card -->
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script_2'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/czmcdcfryly0/public_html/rbpessacash.com/resources/views/admin-views/agent/list.blade.php ENDPATH**/ ?>