<?php $__env->startSection('title', translate('Update Banner')); ?>

<?php $__env->startPush('css_or_js'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content container-fluid">
        <!-- Page Header -->
        <div class="page-header">
            <div class="row align-items-center">
                <div class="col-sm mb-2 mb-sm-0">
                    <h1 class="page-header-title"><i class="tio-image"></i> <?php echo e(translate('banner')); ?> <?php echo e(translate('update')); ?></h1>
                </div>
            </div>
        </div>
        <!-- End Page Header -->
        <div class="row gx-2 gx-lg-3">
            <div class="col-sm-12 col-lg-12 mb-3 mb-lg-2">
                <form action="<?php echo e(route('admin.banner.update',[$banner['id']])); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="form-group col-12">
                            <label class="input-label" for="exampleFormControlInput1"><?php echo e(translate('title')); ?></label>
                            <input type="text" name="title" class="form-control" placeholder="<?php echo e(translate('title')); ?>" value="<?php echo e($banner['title']); ?>" required>
                        </div>
                        <div class="form-group col-12 col-md-6">
                            <label class="input-label" for="exampleFormControlInput1"><?php echo e(translate('URL')); ?></label>
                            <input type="text" name="url" class="form-control" placeholder="<?php echo e(translate('URL')); ?>" value="<?php echo e($banner['url']); ?>"  required>
                        </div>
                        <div class="form-group col-12 col-md-6">
                            <label class="input-label" for="exampleFormControlInput1"><?php echo e(translate('receiver')); ?></label>
                            <select name="receiver" class="form-control js-select2-custom" id="receiver">
                                <option value="" selected disabled><?php echo e(translate('Update receiver')); ?></option>
                                <option value="all"><?php echo e(translate('All')); ?></option>
                                <option value="customers"><?php echo e(translate('Customers')); ?></option>
                                <option value="agents"><?php echo e(translate('Agents')); ?></option>
                            </select>
                        </div>
                        <div class="form-group col-12">
                            <label class="text-dark"><?php echo e(translate('image')); ?></label><small style="color: red; padding: 0 5px">* ( <?php echo e(translate('ratio')); ?> 3:1 )</small>
                            <div class="custom-file">
                                <input type="file" name="image" id="customFileEg1" class="custom-file-input"
                                       accept=".jpg, .png, .jpeg, .gif, .bmp, .tif, .tiff|image/*">
                                <label class="custom-file-label" for="customFileEg1"><?php echo e(translate('choose')); ?> <?php echo e(translate('file')); ?></label>
                            </div>
                            <div class="text-center mt-4">
                                <img style="width: 30%;border: 1px solid; border-radius: 10px;" id="viewer"
                                     src="<?php echo e(asset('storage/app/public/banner')); ?>/<?php echo e($banner['image']); ?>"
                                     onerror="this.src='<?php echo e(asset('public/assets/admin/img/1920x400/img2.jpg')); ?>'"
                                     alt="image"/>
                            </div>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary mt-4"><?php echo e(translate('update')); ?></button>
                </form>
            </div>
            <!-- End Table -->
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script_2'); ?>
    <script>
        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#viewer').attr('src', e.target.result);
                }

                reader.readAsDataURL(input.files[0]);
            }
        }

        $("#customFileEg1").change(function () {
            readURL(this);
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/czmcdcfryly0/public_html/rbpessacash.com/resources/views/admin-views/banner/edit.blade.php ENDPATH**/ ?>