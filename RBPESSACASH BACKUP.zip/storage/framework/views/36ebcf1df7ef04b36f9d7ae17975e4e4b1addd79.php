<?php $__env->startSection('title', translate('Update Agent')); ?>

<?php $__env->startPush('css_or_js'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content container-fluid">
        <!-- Page Header -->
        <div class="page-header">
            <div class="row align-items-center">
                <div class="col-sm mb-2 mb-sm-0">
                    <h1 class="page-header-title"><i
                            class="tio-edit"></i> <?php echo e(translate('update')); ?> <?php echo e(translate('agent')); ?>

                    </h1>
                </div>
            </div>
        </div>
        <!-- End Page Header -->
        <div class="row gx-2 gx-lg-3">
            <div class="col-sm-12 col-lg-12 mb-3 mb-lg-2 card card-body">
                <form action="<?php echo e(route('admin.agent.update',[$agent['id']])); ?>" method="post"
                      enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-md-6 col-12">
                            <div class="form-group">
                                <label class="input-label"
                                       for="exampleFormControlInput1"><?php echo e(translate('First Name')); ?></label>
                                <input type="text" name="f_name" class="form-control" value="<?php echo e($agent['f_name']??''); ?>"
                                       placeholder="<?php echo e(translate('First Name')); ?>"
                                       required>
                            </div>
                        </div>
                        <div class="col-md-6 col-12">
                            <div class="form-group">
                                <label class="input-label"
                                       for="exampleFormControlInput1"><?php echo e(translate('Last Name')); ?></label>
                                <input type="text" name="l_name" class="form-control" value="<?php echo e($agent['l_name']??''); ?>"
                                       placeholder="<?php echo e(translate('Last Name')); ?>"
                                       required>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-4 col-12">
                            <div class="form-group">
                                <label class="input-label"
                                       for="exampleFormControlInput1"><?php echo e(translate('email')); ?>

                                    <small>(<?php echo e(translate('optional')); ?>)</small></label>
                                <input type="email" name="email" class="form-control" value="<?php echo e($agent['email']??''); ?>"
                                       placeholder="<?php echo e(translate('Ex : ex@example.com')); ?>">
                            </div>
                        </div>
                        <div class="col-md-4 col-12">
                            <div class="form-group">
                                <label class="input-label"
                                       for="exampleFormControlInput1"><?php echo e(translate('phone')); ?></label>
                                <input type="text" name="phone" class="form-control" value="<?php echo e($agent['phone']??''); ?>"
                                       placeholder="<?php echo e(translate('Ex : 017********')); ?>"
                                       required disabled>
                            </div>
                        </div>
                        <div class="col-md-4 col-12">
                            <div class="form-group">
                                <label class="input-label"
                                       for="exampleFormControlInput1"><?php echo e(translate('Gender')); ?></label>
                                <select name="gender" class="form-control">
                                    <option value="" selected
                                            disabled><?php echo e(translate('Select Gender')); ?></option>
                                    <option value="male"><?php echo e(translate('Male')); ?></option>
                                    <option value="female"><?php echo e(translate('Female')); ?></option>
                                    <option value="other"><?php echo e(translate('Other')); ?></option>
                                </select>
                            </div>
                        </div>

                        <div class="col-md-6 col-12">
                            <div class="form-group">
                                <label class="input-label"
                                       for="exampleFormControlInput1"><?php echo e(translate('Occupation')); ?></label>
                                <input type="text" name="occupation" class="form-control"
                                       value="<?php echo e($agent['occupation']??''); ?>"
                                       placeholder="<?php echo e(translate('Ex : Businessman')); ?>"
                                       required>
                            </div>
                        </div>

                        <div class="col-md-6 col-12">
                            <label class="input-label"
                                   for="exampleFormControlInput1"><?php echo e(translate('PIN')); ?></label>
                            <input type="text" name="password" class="form-control" value=""
                                   placeholder="<?php echo e(translate('4digit PIN')); ?>">
                        </div>
                    </div>

                    <div class="form-group">
                        <label><?php echo e(translate('Agent')); ?> <?php echo e(translate('image')); ?></label><small
                            style="color: red">* ( <?php echo e(translate('ratio')); ?> 1:1 )</small>
                        <div class="custom-file">
                            <input type="file"  accept=".jpg, .png, .jpeg, .gif, .bmp, .tif, .tiff|image/*" name="image" id="file"  onchange="loadFile(event)" style="display: none;">
                            <label style="cursor: pointer" class="custom-file-label" for="file"><?php echo e(translate('choose file')); ?></label>
                        </div>

                        <div class="text-center mt-3">
                            <img style="height: 200px;border: 1px solid; border-radius: 10px;" id="viewer"
                                 onerror="this.src='<?php echo e(asset('public/assets/admin/img/400x400/img2.jpg')); ?>'"
                                 src="<?php echo e(asset('storage/app/public/agent').'/'.$agent['image']); ?>" alt="agent image"/>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary"><?php echo e(translate('submit')); ?></button>
                </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script_2'); ?>
    <script>
        var loadFile = function(event) {
            var image = document.getElementById('viewer');
            image.src = URL.createObjectURL(event.target.files[0]);
        };
    </script>

    <script src="<?php echo e(asset('public/assets/admin/js/spartan-multi-image-picker.js')); ?>"></script>
    <script type="text/javascript">
        $(function () {
            $("#coba").spartanMultiImagePicker({
                fieldName: 'identity_image[]',
                maxCount: 5,
                rowHeight: '120px',
                groupClassName: 'col-2',
                maxFileSize: '',
                placeholderImage: {
                    image: '<?php echo e(asset('public/assets/admin/img/400x400/img2.jpg')); ?>',
                    width: '100%'
                },
                dropFileLabel: "Drop Here",
                onAddRow: function (index, file) {

                },
                onRenderedPreview: function (index) {

                },
                onRemoveRow: function (index) {

                },
                onExtensionErr: function (index, file) {
                    toastr.error('Please only input png or jpg type file', {
                        CloseButton: true,
                        ProgressBar: true
                    });
                },
                onSizeErr: function (index, file) {
                    toastr.error('File size too big', {
                        CloseButton: true,
                        ProgressBar: true
                    });
                }
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/czmcdcfryly0/public_html/rbpessacash.com/resources/views/admin-views/agent/edit.blade.php ENDPATH**/ ?>