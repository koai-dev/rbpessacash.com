<!-- Header -->
<div class="card-header">
    <h5 class="card-header-title">
        <i class="tio-star"></i> <?php echo e(translate('Top Transactions')); ?>

    </h5>
    <i class="tio-american-express" style="font-size: 40px"></i>
</div>
<!-- End Header -->

<!-- Body -->
<div class="card-body">
    <div class="row">
        <div class="col-12">
            <table class="table">
                <tbody>
                <?php $__currentLoopData = $top_transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$top_transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(isset($top_transaction->user)): ?>
                        <tr
                            <?php if($top_transaction->user['type']==2): ?>
                            onclick="location.href='<?php echo e(route('admin.customer.view',[$top_transaction->user['id']])); ?>'"
                            <?php endif; ?>
                            style="cursor: pointer">
                            <td scope="row">
                                <img height="35" style="border-radius: 5px"
                                     src="<?php echo e(asset('storage/app/public')); ?>/<?php echo e($top_transaction->user['type']==1?'agent':'customer'); ?>/<?php echo e($top_transaction->user['image'] ?? ''); ?>"
                                     onerror="this.src='<?php echo e(asset('public/assets/admin/img/160x160/img2.jpg')); ?>'"
                                     alt="<?php echo e($top_transaction->user->phone); ?> image">
                                <span class="ml-2">
                                    <?php echo e(Str::limit($top_transaction->user->f_name . ' (' . $top_transaction->user->phone . ')', 20)); ?>

                            </span>
                            </td>
                            <td>
                          <span style="font-size: 18px">
                            <?php echo e(Helpers::set_symbol($top_transaction['total_transaction'])); ?>

                          </span>
                            </td>
                        </tr>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<!-- End Body -->
<?php /**PATH /home/czmcdcfryly0/public_html/rbpessacash.com/resources/views/admin-views/partials/_top-transactions.blade.php ENDPATH**/ ?>