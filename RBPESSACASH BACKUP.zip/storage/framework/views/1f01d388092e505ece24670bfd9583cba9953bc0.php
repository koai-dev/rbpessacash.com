<?php $__env->startSection('title', translate('Log')); ?>

<?php $__env->startPush('css_or_js'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

    <div class="content container-fluid">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a
                        href="<?php echo e(route('admin.dashboard')); ?>"><?php echo e(translate('Dashboard')); ?></a>
                </li>
                <li class="breadcrumb-item"
                    aria-current="page"><?php echo e(translate('Log')); ?></li>
            </ol>
        </nav>

        <!-- Page Header -->
        <div class="page-header mb-3">
            <div class="flex-between row mx-1">
                <div>
                    <h1 class="page-header-title"></h1>
                </div>
            </div>
            <!-- Nav Scroller -->
            <div class="js-nav-scroller hs-nav-scroller-horizontal">
                <!-- Nav -->
                <ul class="nav nav-tabs page-header-tabs">
                    <li class="nav-item">
                        <a class="nav-link"
                           <?php if($user->type == 1): ?>
                           href="<?php echo e(route('admin.agent.view',[$user['id']])); ?>"
                           <?php elseif($user->type == 2): ?>
                           href="<?php echo e(route('admin.customer.view',[$user['id']])); ?>"
                           <?php else: ?>
                           href="#"
                            <?php endif; ?>
                        ><?php echo e(translate('details')); ?></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link"
                           <?php if($user->type == 1): ?>
                           href="<?php echo e(route('admin.agent.transaction',[$user['id']])); ?>"
                           <?php elseif($user->type == 2): ?>
                           href="<?php echo e(route('admin.customer.transaction',[$user['id']])); ?>"
                           <?php else: ?>
                           href="#"
                            <?php endif; ?>
                        ><?php echo e(translate('Transactions')); ?></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active"
                           <?php if(isset($user) && $user->type == 1): ?>
                           href="<?php echo e(route('admin.agent.log',[$user['id']])); ?>"
                           <?php elseif(isset($user) && $user->type == 2): ?>
                           href="<?php echo e(route('admin.customer.log',[$user['id']])); ?>"
                           <?php else: ?>
                           href="#"
                            <?php endif; ?>
                        ><?php echo e(translate('Logs')); ?></a>
                    </li>
                </ul>
                <!-- End Nav -->
            </div>
            <!-- End Nav Scroller -->
        </div>
        <!-- End Page Header -->

        <div class="row gx-2 gx-lg-3">
            <div class="col-sm-12 col-lg-12 mb-3 mb-lg-2">
                <div class="card">
                    <div class="card-header flex-between">
                        <div class="flex-start">
                            <h5 class="card-header-title"><?php echo e(translate('Agent Log')); ?></h5>
                            <h5 class="card-header-title text-primary mx-1">(<?php echo e($user_logs->total()); ?>)</h5>
                        </div>
                        <div>
                            <form action="<?php echo e(url()->current()); ?>" method="GET">
                                <div class="input-group">
                                    <input id="datatableSearch_" type="search" name="search"
                                           class="form-control"
                                           placeholder="<?php echo e(translate('Search')); ?>" aria-label="Search"
                                           value="<?php echo e($search); ?>" required autocomplete="off">
                                    <div class="input-group-append">
                                        <button type="submit" class="input-group-text"><i class="tio-search"></i>
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <!-- Table -->
                    <div class="table-responsive datatable-custom">
                        <table
                            class="table table-hover table-borderless table-thead-bordered table-nowrap table-align-middle card-table"
                            style="width: 100%">
                            <thead class="thead-light">
                            <tr>
                                <th ><?php echo e(translate('name')); ?></th>
                                <th><?php echo e(translate('phone')); ?></th>
                                <th><?php echo e(translate('ip_address')); ?></th>
                                <th><?php echo e(translate('device_id')); ?></th>
                                <th><?php echo e(translate('browser')); ?></th>
                                <th><?php echo e(translate('os')); ?></th>
                                <th><?php echo e(translate('device_model')); ?></th>
                                <th><?php echo e(translate('login_time')); ?></th>
                            </tr>
                            </thead>

                            <tbody id="set-rows">
                            <?php $__currentLoopData = $user_logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$user_log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($user_log->user): ?>
                                    <tr>
                                        <td>
                                            <a class="d-block font-size-sm text-body"
                                               href="<?php echo e(route('admin.customer.view',[$user_log->user['id']])); ?>">
                                                <?php echo e($user_log->user['f_name'].' '.$user_log->user['l_name']); ?>

                                            </a>
                                        </td>
                                        <td>
                                            <?php echo e($user_log->user['phone']); ?>

                                        </td>
                                        <td><?php echo e($user_log->ip_address); ?></td>
                                        <td><?php echo e($user_log->device_id); ?></td>
                                        <td><?php echo e($user_log->browser); ?></td>
                                        <td><?php echo e($user_log->os); ?></td>
                                        <td><?php echo e($user_log->device_model); ?></td>
                                        <td><?php echo e(date('d-M-Y H:iA', strtotime($user_log->created_at))); ?></td>
                                    </tr>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                        <hr>
                        <table>
                            <tfoot>
                            <?php echo $user_logs->links(); ?>

                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
            <!-- End Table -->
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script_2'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/czmcdcfryly0/public_html/rbpessacash.com/resources/views/admin-views/view/log.blade.php ENDPATH**/ ?>