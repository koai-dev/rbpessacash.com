<?php $__env->startSection('title', translate('Add_withdrawal_methods')); ?>

<?php $__env->startPush('css_or_js'); ?>
    <script src="https://use.fontawesome.com/74721296a6.js"></script>
<?php $__env->stopPush(); ?>


<?php $__env->startSection('content'); ?>
    <div class="content container-fluid">
        <!-- Page Header -->
        <div class="page-header">
            <div class="row align-items-center">
                <div class="col-sm mb-2 mb-sm-0 flex-between">
                    <h1 class="page-header-title"><?php echo e(translate('Withdrawal Method Add')); ?>

                        <i class="tio-info" data-toggle="tooltip" data-placement="top"
                           title="<?php echo e(translate('Agent/Customer will use these methods to withdraw their money directly from admin')); ?>">
                        </i>
                    </h1>
                    <h1><i class="tio-add-circle-outlined"></i></h1>
                </div>
            </div>
        </div>
        <!-- End Page Header -->
        <div class="row">
            <div class="col-sm-12 col-lg-12 mb-3 mb-lg-2 card card-body">
                <form action="<?php echo e(route('admin.withdrawal_methods.store')); ?>" method="post"
                      enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-md-10 col-12">
                            <div class="form-group">
                                <label class="input-label"><?php echo e(translate('Method Name')); ?></label>
                                <input type="text" maxlength="255" name="method_name" id="method_name" class="form-control" placeholder="" required>
                            </div>
                        </div>
                        <div class="col-md-2 col-12 mt-1">
                            <button type="button" class="btn btn-secondary w-100 mt-0 mt-md-4 mb-4 mb-md-0" id="add-field"><?php echo e(translate('Add Fields')); ?></button>
                        </div>
                    </div>

                    <div id="method-field"></div>

                    <button type="submit" class="btn btn-primary float-right"><?php echo e(translate('Add Method')); ?></button>
                    <button type="button" class="btn btn-danger float-right mx-1" id="reset"><?php echo e(translate('Reset')); ?></button>
                </form>
            </div>

            <!-- Table -->
            <div class="col-sm-12 col-lg-12 mb-3 mb-lg-2 mt-2 card card-body">
                    <!-- Table -->
                    <div class="table-responsive datatable-custom">
                        <table
                            class="table table-borderless table-thead-bordered table-nowrap table-align-middle card-table">
                            <thead class="thead-light">
                            <tr>
                                <th><?php echo e(translate('#NO')); ?></th>
                                <th><?php echo e(translate('Method Name')); ?></th>
                                <th><?php echo e(translate('Fields')); ?></th>
                                <th><?php echo e(translate('action')); ?></th>
                            </tr>
                            </thead>

                            <tbody id="set-rows">
                            <?php $__currentLoopData = $withdrawal_methods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$withdrawal_method): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($withdrawal_methods->firstitem()+$key); ?></td>
                                    <td>
                                        <?php echo e($withdrawal_method['method_name']); ?>

                                    </td>
                                    <td>
                                        <?php $__currentLoopData = $withdrawal_method['method_fields']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$fields): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <span class="badge badge-pill badge-light">
                                                <?php echo e(translate('Name') . ': ' . $fields['input_name'] . ' | ' . translate('Type') . ': ' . $fields['input_type'] . ' | ' . translate('Placeholder') . ': ' . $fields['placeholder']); ?>

                                            </span><br/>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                    <td>
                                        <button class="btn-sm btn-danger p-1 m-1"  onclick="deleteItem(<?php echo e($withdrawal_method->id); ?>)">
                                            <i class="fa fa-trash p-1" aria-hidden="true"></i>
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                        <hr>
                        <table>
                            <tfoot>
                            <?php echo $withdrawal_methods->links(); ?>

                            </tfoot>
                        </table>
                    </div>
            </div>
            <!-- End Table -->
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('script'); ?>
    <script src="https://code.jquery.com/jquery-3.6.1.min.js" integrity="sha256-o88AwQnZB+VDvE9tvIXrMQaPlFFSUTR+nldQm1LuPXQ=" crossorigin="anonymous"></script>
    <script>
        // function fieldTypeChange(count_no) {
        //     $("#field_name_"+count_no).get(0).type = $("#field_type_"+count_no).val();
        // }
        function delete_input_field(row_id) {
            //console.log(row_id);
            $( `#field-row--${row_id}` ).remove();
            count--;
        }


        jQuery(document).ready(function ($) {
            count = 1;
            $('#add-field').on('click', function (event) {
                if(count <= 15) {
                    event.preventDefault();

                    $('#method-field').append(
                        `<div class="row bg-light" id="field-row--${count}">
                            <div class="col-md-4 col-12">
                                <div class="form-group">
                                    <label class="input-label"><?php echo e(translate('Input Field Type')); ?> </label>
                                    <select class="form-control" name="field_type[]" id="field_type_${count}" required onchange="fieldTypeChange(${count})">
                                        <option value="string"><?php echo e(translate('String')); ?></option>
                                        <option value="number"><?php echo e(translate('Number')); ?></option>
                                        <option value="date"><?php echo e(translate('Date')); ?></option>
                                        <option value="password"><?php echo e(translate('Password')); ?></option>
                                        <option value="email"><?php echo e(translate('Email')); ?></option>
                                        <option value="phone"><?php echo e(translate('Phone')); ?></option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-4 col-12">
                                <div class="form-group">
                                    <label class="input-label"><?php echo e(translate('Input Field Name')); ?> </label>
                                    <input type="text" name="field_name[]" class="form-control" maxlength="255" placeholder="" id="field_name_${count}" required>
                                </div>
                            </div>
                            <div class="col-md-3 col-12">
                                <div class="form-group">
                                    <label class="input-label"><?php echo e(translate('Input Field Placeholder/Hints')); ?> </label>
                                    <input type="text" name="placeholder[]" class="form-control" maxlength="255" placeholder="" required>
                                </div>
                            </div>
                            <div class="col-1 p-1"
                                 data-toggle="tooltip" data-placement="top" title="<?php echo e(translate('Remove the input field')); ?>">
                                <div class="btn form-control mt-4" onclick="delete_input_field(${count})">
                                    <i class="tio-delete-outlined"></i>
                                </div>
                            </div>
                        </div>`
                    );

                    count++;
                } else {
                    Swal.fire({
                        title: '<?php echo e(translate('Reached maximum')); ?>',
                        confirmButtonText: '<?php echo e(translate('ok')); ?>',
                    });
                }
            })

            $('#reset').on('click', function (event) {
                $('#method-field').html("");
                $('#method_name').val("");
                count=1;
            })
        });
    </script>

    <script>
        function deleteItem(id) {
            // var id = $(this).attr("id");
            Swal.fire({
                title: '<?php echo e(translate('Are you sure')); ?>?',
                text: "<?php echo e(translate('You will not be able to revert this')); ?>!",
                showCancelButton: true,
                confirmButtonColor: '#174F5B',
                cancelButtonColor: '#EA295E',
                confirmButtonText: '<?php echo e(translate('Yes, delete it')); ?>!'
            }).then((result) => {
                if (result.value) {
                    $.ajaxSetup({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
                        }
                    });
                    $.ajax({
                        url: "<?php echo e(route('admin.withdrawal_methods.delete')); ?>",
                        method: 'POST',
                        data: {id: id},
                        success: function () {
                            toastr.success('<?php echo e(translate('Removed successfully')); ?>');
                            location.reload();
                        }
                    });
                }
            })
        }
    </script>
<?php $__env->stopPush(); ?>


<?php $__env->startPush('script_2'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/czmcdcfryly0/public_html/rbpessacash.com/resources/views/admin-views/withdrawal/index.blade.php ENDPATH**/ ?>