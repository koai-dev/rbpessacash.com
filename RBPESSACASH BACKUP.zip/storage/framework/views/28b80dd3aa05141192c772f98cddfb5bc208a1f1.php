<?php $__env->startSection('title', translate('Linked Website')); ?>

<?php $__env->startPush('css_or_js'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content container-fluid">
        <!-- Page Header -->
        <div class="page-header">
            <div class="row align-items-center">
                <div class="col-sm mb-2 mb-sm-0">
                    <h1 class="page-header-title"><i
                            class="tio-add-circle-outlined"></i> <?php echo e(translate('Add New Website')); ?>

                    </h1>
                </div>
            </div>
        </div>
        <!-- End Page Header -->
        <div class="row gx-2 gx-lg-3">
            <div class="col-sm-12 col-lg-12 mb-3 mb-lg-2">
                <form action="<?php echo e(route('admin.linked-website')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('put'); ?>
                    <div class="row">
                        <div class="col-6">
                            <div class="form-group">
                                <label class="input-label"
                                       for="exampleFormControlInput1"><?php echo e(translate('name')); ?></label>
                                <input type="text" name="name" class="form-control" value="<?php echo e($linked_website['name']); ?>"
                                       placeholder="<?php echo e(translate('example')); ?>" required>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label class="input-label"
                                       for="exampleFormControlInput1"><?php echo e(translate('URL')); ?></label>
                                <input type="text" name="url" class="form-control" value="<?php echo e($linked_website['url']); ?>"
                                       placeholder="<?php echo e(translate('""_www.example.com')); ?>" required>
                            </div>
                        </div>

                        <div class="form-group col-12">
                            <label><?php echo e(translate('image')); ?></label><small style="color: red">* ( <?php echo e(translate('ratio')); ?> 1:1 )</small>
                            <div class="custom-file">
                                <input type="file" name="image" id="customFileEg1" class="custom-file-input"
                                       accept=".jpg, .png, .jpeg, .gif, .bmp, .tif, .tiff|image/*" >
                                <label class="custom-file-label" for="customFileEg1"><?php echo e(translate('choose')); ?> <?php echo e(translate('file')); ?></label>
                            </div>
                            <center class="mt-4">
                                <img style="height: 200px;border: 1px solid; border-radius: 10px;" id="viewer"
                                     src="<?php echo e(asset('storage/app/public/website')); ?>/<?php echo e($linked_website['image']); ?>"
                                     onerror="this.src='<?php echo e(asset('public/assets/admin/img/1920x400/img2.jpg')); ?>'"
                                     alt="delivery-man image"/>
                            </center>
                        </div>
                    </div>
                    <input type="hidden" name="id" class="form-control" value="<?php echo e($linked_website['id']); ?>">

                    <button type="submit" class="btn btn-primary"><?php echo e(translate('submit')); ?></button>
                </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script_2'); ?>
    <script>
        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#viewer').attr('src', e.target.result);
                }

                reader.readAsDataURL(input.files[0]);
            }
        }

        $("#customFileEg1").change(function () {
            readURL(this);
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/czmcdcfryly0/public_html/rbpessacash.com/resources/views/admin-views/business-settings/linked-website-edit.blade.php ENDPATH**/ ?>