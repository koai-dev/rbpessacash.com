<?php $__env->startSection('title', translate('Withdraw_Requests')); ?>

<?php $__env->startPush('css_or_js'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content container-fluid">
        <!-- Page Header -->
        <div class="page-header">
            <div class="row align-items-center">
                <div class="col-sm mb-2 mb-sm-0 flex-between">
                    <h1 class="page-header-title"><?php echo e(translate('Withdraw_Requests')); ?></h1>
                    <h1><i class="tio-user-switch"></i></h1>
                </div>
            </div>
        </div>
        <!-- End Page Header -->
        <div class="row gx-2 gx-lg-3">
            <div class="col-sm-12 col-lg-12 mb-3 mb-lg-2">
                <div class="card">
                    <div class="card-header flex-between">
                        <div class="flex-start">
                            <h5 class="card-header-title"><?php echo e(translate('transaction Table')); ?></h5>
                            <h5 class="card-header-title text-primary mx-1">(<?php echo e($withdraw_requests->total()); ?>)</h5>
                        </div>
                        <div class="flex-between">
                            <div class="form-group px-1">
                                    <a class="btn-sm btn-secondary form-control" href="<?php echo e(route('admin.withdraw.download', ['withdrawal_method'=>$method,'search'=>$search])); ?>"><?php echo e(translate('Export')); ?></a>
                            </div>
                            <div class="form-group px-1">
                                <select name="withdrawal_method" class="form-control js-select2-custom" id="withdrawal_method" required>
                                    <option value="all" selected><?php echo e(translate('Filter by method')); ?></option>
                                    <?php $__currentLoopData = $withdrawal_methods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $withdrawal_method): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($withdrawal_method->id); ?>" <?php echo e($method == $withdrawal_method->id ? 'selected' : ''); ?>><?php echo e(translate($withdrawal_method->method_name)); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div>
                                <form action="<?php echo e(url()->current()); ?>" method="GET">
                                    <div class="input-group">
                                        <input id="datatableSearch_" type="search" name="search"
                                               class="form-control"
                                               placeholder="<?php echo e(translate('Search')); ?>" aria-label="Search"
                                               value="<?php echo e($search??''); ?>" required autocomplete="off">
                                        <div class="input-group-append">
                                            <button type="submit" class="input-group-text"><i class="tio-search"></i>
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <!-- Table -->
                    <div class="table-responsive datatable-custom">
                        <table
                            class="table table-borderless table-thead-bordered table-nowrap table-align-middle card-table table-striped">
                            <thead class="thead-light">
                            <tr>
                                <th><?php echo e(translate('No#')); ?></th>
                                <th><?php echo e(translate('Sender')); ?></th>
                                <th><?php echo e(translate('Sender Type')); ?></th>
                                <th><?php echo e(translate('Requested Amount')); ?></th>
                                <th><?php echo e(translate('Withdrawal Method')); ?></th>
                                <th><?php echo e(translate('Withdrawal Method Fields')); ?></th>
                                <th><?php echo e(translate('Sender_Note')); ?></th>
                                <th><?php echo e(translate('Admin_Note')); ?></th>
                                <th><?php echo e(translate('Request_Status')); ?></th>
                                <th><?php echo e(translate('Payment_Status')); ?></th>
                                <th><?php echo e(translate('Requested time')); ?></th>
                            </tr>
                            </thead>

                            <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $withdraw_requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$withdraw_request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($withdraw_requests->firstitem()+$key); ?></td>
                                    <td>
                                        <?php if($withdraw_request->user): ?>
                                            <span class="d-block font-size-sm text-body">
                                                <a href="<?php echo e(route('admin.customer.view',[$withdraw_request->user->id])); ?>">
                                                    <?php echo e($withdraw_request->user->f_name . ' ' . $withdraw_request->user->l_name); ?>

                                                </a>
                                            </span>
                                        <?php else: ?>
                                            <span class="badge badge-pill"><?php echo e(translate('User_not_available')); ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($withdraw_request->user): ?>
                                            <small class="badge badge-pill">
                                                <?php echo e($withdraw_request->user->type == 1 ? translate('Agent') : ($withdraw_request->user->type == 2 ? translate('Customer') : '')); ?>

                                            </small>
                                        <?php else: ?>
                                            <span class="badge badge-pill"><?php echo e(translate('Not_available')); ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e(Helpers::set_symbol($withdraw_request->amount)); ?></td>
                                    <td><span class="badge badge-pill"><?php echo e(translate($withdraw_request->withdrawal_method ? $withdraw_request->withdrawal_method->method_name : '')); ?></span></td>
                                    <td>
                                        <?php $__currentLoopData = $withdraw_request->withdrawal_method_fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e(translate($key) . ': ' . $item); ?> <br/>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <td><?php echo e($withdraw_request->sender_note); ?></td>
                                    <td><?php echo e($withdraw_request->sender_note); ?></td>
                                    <td>
                                        <?php if( $withdraw_request->request_status == 'pending' ): ?>
                                            <div>
                                                <a href="<?php echo e(route('admin.withdraw.status_update', ['request_id'=>$withdraw_request->id, 'request_status'=>'approve'])); ?>" class="btn btn-primary btn-sm"> <?php echo e(translate('Approve')); ?></a>
                                                <a href="<?php echo e(route('admin.withdraw.status_update', ['request_id'=>$withdraw_request->id, 'request_status'=>'deny'])); ?>" class="btn btn-warning btn-sm"> <?php echo e(translate('Deny')); ?></a>
                                            </div>
                                        <?php elseif( $withdraw_request->request_status == 'approved' ): ?>
                                            <span class="badge badge-success"> <?php echo e(translate('Approved')); ?></span>
                                        <?php elseif( $withdraw_request->request_status == 'denied' ): ?>
                                            <span class="badge badge-danger"> <?php echo e(translate('Denied')); ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($withdraw_request->is_paid ): ?>
                                            <span class="badge badge-pill badge-success"><?php echo e(translate('Paid')); ?></span>
                                        <?php else: ?>
                                            <span class="badge badge-pill badge-danger"><?php echo e(translate('Not_Paid')); ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td style="width: 10%"><?php echo e(date_time_formatter($withdraw_request->created_at)); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr><td colspan="10" class="text-center"><?php echo e(translate('No_data_available')); ?></td></tr>
                            <?php endif; ?>
                            </tbody>
                        </table>

                        <hr>
                        <table>
                            <tfoot>
                            <?php echo $withdraw_requests->links(); ?>

                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
            <!-- End Table -->
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script_2'); ?>
    <script>
        $("#withdrawal_method").on('change', function (event) {
            location.href = "<?php echo e(route('admin.withdraw.requests')); ?>" + '?withdrawal_method=' + $(this).val();
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/czmcdcfryly0/public_html/rbpessacash.com/resources/views/admin-views/withdraw/index.blade.php ENDPATH**/ ?>