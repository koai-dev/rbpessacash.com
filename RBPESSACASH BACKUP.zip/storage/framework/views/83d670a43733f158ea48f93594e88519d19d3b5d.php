<?php $__env->startSection('title', translate('transaction List')); ?>

<?php $__env->startPush('css_or_js'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content container-fluid">
        <!-- Page Header -->
        <div class="page-header">
            <div class="row align-items-center">
                <div class="col-sm mb-2 mb-sm-0 flex-between">
                    <h1 class="page-header-title"><?php echo e(translate('transaction')); ?></h1>
                    <h1><i class="tio-user-switch"></i></h1>
                </div>
            </div>
        </div>
        <!-- End Page Header -->
        <div class="row gx-2 gx-lg-3">
            <div class="col-sm-12 col-lg-12 mb-3 mb-lg-2">
                <div class="card">
                    <div class="card-header flex-between">
                        <div class="flex-start">
                            <h5 class="card-header-title"><?php echo e(translate('transaction Table')); ?></h5>
                            <h5 class="card-header-title text-primary mx-1">(<?php echo e($transactions->total()); ?>)</h5>
                        </div>
                        <div>
                            <form action="<?php echo e(url()->current()); ?>" method="GET">
                                <div class="input-group">
                                    <input id="datatableSearch_" type="search" name="search"
                                           class="form-control"
                                           placeholder="<?php echo e(translate('Search')); ?>" aria-label="Search"
                                           value="<?php echo e($search); ?>" required autocomplete="off">
                                    <div class="input-group-append">
                                        <button type="submit" class="input-group-text"><i class="tio-search"></i>
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <!-- Table -->
                    <div class="table-responsive datatable-custom">
                        <table
                            class="table table-borderless table-thead-bordered table-nowrap table-align-middle card-table table-striped">
                            <thead class="thead-light">
                            <tr>
                                <th><?php echo e(translate('No#')); ?></th>
                                <th><?php echo e(translate('Transaction Id')); ?></th>
                                <th><?php echo e(translate('Sender')); ?></th>
                                <th><?php echo e(translate('Receiver')); ?></th>
                                <th><?php echo e(translate('Debit')); ?></th>
                                <th><?php echo e(translate('Credit')); ?></th>
                                <th><?php echo e(translate('Type')); ?></th>
                                <th><?php echo e(translate('Balance')); ?></th>
                                <th><?php echo e(translate('Time')); ?></th>
                            </tr>
                            </thead>

                            <tbody>
                            <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($transactions->firstitem()+$key); ?></td>
                                    <td><?php echo e($transaction->transaction_id??''); ?></td>
                                    <td>
                                        <?php ($sender_info = Helpers::get_user_info($transaction['from_user_id'])); ?>
                                        <?php if($sender_info != null): ?>
                                            <a href="<?php echo e(route('admin.customer.view',[$transaction['to_user_id']])); ?>">
                                                <?php echo e($sender_info->f_name ?? ''); ?> <?php echo e($sender_info->phone ?? ''); ?>

                                            </a>
                                        <?php else: ?>
                                            <span class="text-muted badge badge-danger text-dark"><?php echo e(translate('User unavailable')); ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php ($receiver_info = Helpers::get_user_info($transaction['to_user_id'])); ?>
                                        <?php if($receiver_info != null): ?>
                                            <a href="<?php echo e(route('admin.customer.view',[$transaction['to_user_id']])); ?>">
                                                <?php echo e($receiver_info->f_name ?? ''); ?> <?php echo e($receiver_info->phone ?? ''); ?>

                                            </a>
                                        <?php else: ?>
                                            <span class="text-muted badge badge-danger text-dark"><?php echo e(translate('User unavailable')); ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span class="">
                                            <?php echo e(Helpers::set_symbol($transaction['debit'])); ?>

                                        </span>
                                    </td>
                                    <td>
                                        <span class="">
                                            <?php echo e(Helpers::set_symbol($transaction['credit'])); ?>

                                        </span>
                                    </td>
                                    <td>
                                        <span class="text-uppercase text-muted badge badge-light"><?php echo e(translate($transaction['transaction_type'])); ?></span>
                                    </td>
                                    <td>
                                        <span class=""><?php echo e(Helpers::set_symbol($transaction['balance'])); ?></span>
                                    </td>
                                    <td>
                                        <span class="text-muted badge badge-light"><?php echo e($transaction->created_at->diffForHumans()); ?></span>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                        <hr>
                        <table>
                            <tfoot>
                            <?php echo $transactions->links(); ?>

                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
            <!-- End Table -->
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script_2'); ?>
    <script>
        $("#receiver").select2({
            ajax: {
                url: '<?php echo e(route('admin.transaction.get_user')); ?>',
                type: "get",
                data: function (params) {
                    var receiver_type = $('#receiver_type').val();
                    if (receiver_type == null) {
                        swal('<?php echo e(translate('Select_valid_receiver_type_first')); ?>');
                    }
                    console.log("type: " + receiver_type);
                    return {
                        q: params.term, // search term
                        page: params.page,
                        receiver_type: receiver_type
                    };

                },
                processResults: function (data) {
                    console.log("data: " + data);
                    return {
                        results: data
                    };
                },
                __port: function (params, success, failure) {
                    var $request = $.ajax(params);

                    $request.then(success);
                    $request.fail(failure);

                    return $request;
                }
            }
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/czmcdcfryly0/public_html/rbpessacash.com/resources/views/admin-views/transaction/index.blade.php ENDPATH**/ ?>