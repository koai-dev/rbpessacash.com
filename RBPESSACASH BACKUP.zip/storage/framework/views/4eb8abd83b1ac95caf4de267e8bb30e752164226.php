<?php $__env->startSection('title', translate('Agent request money')); ?>

<?php $__env->startPush('css_or_js'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content container-fluid">
        <!-- Page Header -->
        <div class="page-header">
            <div class="row align-items-center">
                <div class="col-sm mb-2 mb-sm-0 flex-between">
                    <h1 class="page-header-title"><?php echo e(translate('Agent Requested Transactions')); ?></h1>
                    <h1><i class="tio-user-switch"></i></h1>
                </div>
            </div>
        </div>
        <!-- End Page Header -->
        <div class="row gx-2 gx-lg-3">
            <div class="col-sm-12 col-lg-12 mb-3 mb-lg-2">
                <div class="card">
                    <div class="card-header flex-between">
                        <div class="flex-start">
                            <h5 class="card-header-title"><?php echo e(translate('transaction Table')); ?></h5>
                            <h5 class="card-header-title text-primary mx-1">(<?php echo e($request_money->total()); ?>)</h5>
                        </div>
                        <div class="flex-between">
                            <div>
                                <form action="<?php echo e(url()->current()); ?>" method="GET">
                                    <div class="input-group">
                                        <input id="datatableSearch_" type="search" name="search"
                                               class="form-control"
                                               placeholder="<?php echo e(translate('Search')); ?>" aria-label="Search"
                                               value="<?php echo e($search); ?>" required autocomplete="off">
                                        <div class="input-group-append">
                                            <button type="submit" class="input-group-text"><i class="tio-search"></i>
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <!-- Table -->
                    <div class="table-responsive datatable-custom">
                        <table
                            class="table table-borderless table-thead-bordered table-nowrap table-align-middle card-table table-striped">
                            <thead class="thead-light">
                            <tr>
                                <th><?php echo e(translate('No#')); ?></th>
                                <th><?php echo e(translate('Agent')); ?></th>
                                <th><?php echo e(translate('Requested Amount')); ?></th>
                                <th><?php echo e(translate('Note')); ?></th>
                                <th><?php echo e(translate('Status')); ?></th>
                                <th><?php echo e(translate('Requested time')); ?></th>
                            </tr>
                            </thead>

                            <tbody>
                            <?php $__currentLoopData = $request_money; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <?php echo e($request_money->firstitem()+$key); ?>

                                    </td>
                                    <td>
                                        <?php ($user = Helpers::get_user_info($items->from_user_id)); ?>
                                        <?php if(isset($user)): ?>
                                            <span class="d-block font-size-sm text-body">
                                                <a href="<?php echo e(route('admin.customer.view',[$user->id])); ?>">
                                                    <?php echo e($user->f_name . ' ' . $user->l_name); ?>

                                                </a>
                                            </span>
                                        <?php else: ?>
                                            <span class="text-muted badge badge-danger text-dark"><?php echo e(translate('User unavailable')); ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e(Helpers::set_symbol($items->amount)); ?></td>
                                    <td style="width: 30%"><?php echo e($items->note); ?></td>
                                    <td>
                                        <?php if(isset($user)): ?>
                                            <?php if( $items->type == 'pending' ): ?>
                                                <div>
                                                    
                                                    <a href="<?php echo e(route('admin.transaction.request_money_status_change', ['approve', 'id'=>$items->id])); ?>" class="btn btn-primary btn-sm"> <?php echo e(translate('Approve')); ?></a>
                                                    <a href="<?php echo e(route('admin.transaction.request_money_status_change', ['deny', 'id'=>$items->id])); ?>" class="btn btn-warning btn-sm"> <?php echo e(translate('Deny')); ?></a>
                                                </div>
                                            <?php elseif( $items->type == 'approved' ): ?>
                                                <span class="badge badge-success"> <?php echo e(translate('Approved')); ?></span>
                                            <?php elseif( $items->type == 'denied' ): ?>
                                                <span class="badge badge-danger"> <?php echo e(translate('Denied')); ?></span>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <?php if( $items->type == 'pending' ): ?>
                                                <div data-toggle="tooltip" data-placement="left" title="<?php echo e(translate('User unavailable')); ?>">
                                                    
                                                    <a href="#" class="btn btn-primary btn-sm disabled"> <?php echo e(translate('Approve')); ?></a>
                                                    <a href="#" class="btn btn-warning btn-sm disabled"> <?php echo e(translate('Deny')); ?></a>
                                                </div>
                                            <?php elseif( $items->type == 'approved' ): ?>
                                                <span class="badge badge-success"> <?php echo e(translate('Approved')); ?></span>
                                            <?php elseif( $items->type == 'denied' ): ?>
                                                <span class="badge badge-danger"> <?php echo e(translate('Denied')); ?></span>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </td>
                                    <td style="width: 10%"><?php echo e($items->created_at->diffForHumans()); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                        <hr>
                        <table>
                            <tfoot>
                            <?php echo $request_money->links(); ?>

                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
            <!-- End Table -->
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script_2'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/czmcdcfryly0/public_html/rbpessacash.com/resources/views/admin-views/transaction/request_money_list.blade.php ENDPATH**/ ?>