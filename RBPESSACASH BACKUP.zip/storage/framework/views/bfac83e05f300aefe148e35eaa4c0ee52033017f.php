<?php $__env->startSection('title', translate('Add New Notification')); ?>

<?php $__env->startPush('css_or_js'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content container-fluid">
        <!-- Page Header -->
        <div class="page-header">
            <div class="row align-items-center">
                <div class="col-sm mb-2 mb-sm-0">
                    <h1 class="page-header-title"><i class="tio-notifications"></i> <?php echo e(translate('notification')); ?></h1>
                </div>
            </div>
        </div>

        <!-- End Page Header -->
        <div class="row gx-2 gx-lg-3">
            <div class="col-sm-12 col-lg-12 mb-3 mb-lg-2 card card-body mx-3">
                <form action="<?php echo e(route('admin.notification.store')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-group row">
                        <div class="col-12 col-md-9">
                            <label class="input-label" for="exampleFormControlInput1"><?php echo e(translate('title')); ?></label>
                            <input type="text" name="title" class="form-control" placeholder="<?php echo e(translate('New Notification')); ?>" required>
                        </div>

                        <div class="col-12 col-md-3 mt-4 mt-md-0">
                            <label class="input-label" for="exampleFormControlInput1"><?php echo e(translate('receiver')); ?></label>
                            <select name="receiver" class="form-control js-select2-custom" id="receiver" required>
                                <option value="all" selected><?php echo e(translate('All')); ?></option>
                                <option value="customers"><?php echo e(translate('Customers')); ?></option>
                                <option value="agents"><?php echo e(translate('Agents')); ?></option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="input-label" for="exampleFormControlInput1"><?php echo e(translate('description')); ?></label>
                        <textarea name="description" class="form-control" required></textarea>
                    </div>
                    <div class="form-group">
                        <label class="text-dark"><?php echo e(translate('image')); ?></label><small style="color: red"> (<?php echo e(translate('ratio 3:1')); ?>)</small>
                        <div class="custom-file">
                            <input type="file" name="image" id="customFileEg1" class="custom-file-input"
                                   accept=".jpg, .png, .jpeg, .gif, .bmp, .tif, .tiff|image/*">
                            <label class="custom-file-label" for="customFileEg1"><?php echo e(translate('choose')); ?> <?php echo e(translate('file')); ?></label>
                        </div>
                        <div class="text-center mt-3">
                            <img style="width: 30%;border: 1px solid; border-radius: 10px;" id="viewer"
                                 src="<?php echo e(asset('public/assets/admin/img/900x400/img1.jpg')); ?>" alt="image"/>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary"><?php echo e(translate('send')); ?> <?php echo e(translate('notification')); ?></button>
                </form>
            </div>

            <div class="col-sm-12 col-lg-12 mb-3 mb-lg-2 mt-2">
                <div class="card">
                    <div class="card-header flex-between">
                        <div class="flex-start">
                            <h5 class="card-header-title"><?php echo e(translate('Notification Table')); ?></h5>
                            <h5 class="card-header-title text-primary mx-1">(<?php echo e($notifications->total()); ?>)</h5>
                        </div>
                        <div>
                            <form action="<?php echo e(url()->current()); ?>" method="GET">
                                <div class="input-group">
                                    <input id="datatableSearch_" type="search" name="search"
                                           class="form-control"
                                           placeholder="<?php echo e(translate('Search')); ?>" aria-label="Search"
                                           value="<?php echo e($search); ?>" required autocomplete="off">
                                    <div class="input-group-append">
                                        <button type="submit" class="input-group-text"><i class="tio-search"></i>
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <!-- Table -->
                    <div class="table-responsive datatable-custom">
                        <table class="table table-borderless table-thead-bordered table-nowrap table-align-middle card-table">
                            <thead class="thead-light">
                            <tr>
                                <th><?php echo e(translate('#')); ?></th>
                                <th><?php echo e(translate('title')); ?></th>
                                <th style="width: 50%"><?php echo e(translate('description')); ?></th>
                                <th><?php echo e(translate('receiver')); ?></th>
                                <th><?php echo e(translate('image')); ?></th>

                                <th style="width: 10%"><?php echo e(translate('action')); ?></th>
                            </tr>
                            </thead>

                            <tbody>
                            <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($notifications->firstitem()+$key); ?></td>
                                    <td>
                                    <span class="d-block font-size-sm text-body">
                                        <?php echo e(substr($notification['title'],0,25)); ?> <?php echo e(strlen($notification['title'])>25?'...':''); ?>

                                    </span>
                                    </td>
                                    <td>
                                        <?php echo e(substr($notification['description'],0,25)); ?> <?php echo e(strlen($notification['description'])>25?'...':''); ?>

                                    </td>
                                    <td>
                                        <?php if($notification['receiver'] == 'all'): ?>
                                            <span class="text-uppercase badge badge-light text-muted"><?php echo e(translate('all')); ?></span>
                                        <?php elseif($notification['receiver'] == 'customers'): ?>
                                            <span class="text-uppercase badge badge-light text-muted"><?php echo e(translate('customers')); ?></span>
                                        <?php elseif($notification['receiver'] == 'agents'): ?>
                                            <span class="text-uppercase badge badge-light text-muted"><?php echo e(translate('agents')); ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($notification['image']!=null): ?>
                                            <img style="height: 75px" class="shadow-image"
                                                 onerror="this.src='<?php echo e(asset('public/assets/admin/img/400x400/img2.jpg')); ?>'"
                                                 src="<?php echo e(asset('storage/app/public/notification')); ?>/<?php echo e($notification['image']); ?>">
                                        <?php else: ?>
                                            <label class="badge badge-light text-muted"><?php echo e(translate('No image available')); ?></label>
                                        <?php endif; ?>
                                    </td>













                                    <td>
                                        <!-- Dropdown -->
                                        <div class="dropdown">
                                            <button class="btn btn-secondary dropdown-toggle" type="button"
                                                    id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true"
                                                    aria-expanded="false">
                                                <i class="tio-settings"></i>
                                            </button>
                                            <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                                <a class="dropdown-item"
                                                   href="<?php echo e(route('admin.notification.edit',[$notification['id']])); ?>"><?php echo e(translate('edit & resend')); ?></a>
                                                <a class="dropdown-item" href="javascript:"
                                                   onclick="$('#notification-<?php echo e($notification['id']); ?>').submit()"><?php echo e(translate('delete')); ?></a>
                                                <form
                                                    action="<?php echo e(route('admin.notification.delete',[$notification['id']])); ?>"
                                                    method="post" id="notification-<?php echo e($notification['id']); ?>">
                                                    <?php echo csrf_field(); ?> <?php echo method_field('delete'); ?>
                                                </form>
                                            </div>
                                        </div>
                                        <!-- End Dropdown -->
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                        <hr>
                        <table>
                            <tfoot>
                            <?php echo $notifications->links(); ?>

                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
            <!-- End Table -->
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script_2'); ?>
    <script>
        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#viewer').attr('src', e.target.result);
                }

                reader.readAsDataURL(input.files[0]);
            }
        }

        $("#customFileEg1").change(function () {
            readURL(this);
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/czmcdcfryly0/public_html/rbpessacash.com/resources/views/admin-views/notification/index.blade.php ENDPATH**/ ?>