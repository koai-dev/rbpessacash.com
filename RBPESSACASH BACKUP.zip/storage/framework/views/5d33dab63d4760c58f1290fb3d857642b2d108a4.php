<?php $__env->startSection('title', translate('Customer List')); ?>

<?php $__env->startPush('css_or_js'); ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <script src="https://use.fontawesome.com/74721296a6.js"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content container-fluid">
        <!-- Page Header -->
        <div class="page-header">
            <div class="row align-items-center mb-3">
                <div class="col-sm flex-between">
                    <h1 class="page-header-title"><i
                            class="tio-user-add"></i> <?php echo e(translate('customers')); ?>

                    </h1>
                    <a href="<?php echo e(route('admin.customer.add')); ?>" class="btn btn-primary pull-right mr-1"><i
                            class="tio-add-circle"></i> <?php echo e(translate('Add')); ?> <?php echo e(translate('Customer')); ?>

                    </a>
                </div>
            </div>
            <!-- End Row -->
        </div>
        <!-- End Page Header -->

        <!-- Card -->
        <div class="card">
            <!-- Header -->
            <div class="card-header">
                <div class="flex-start">
                    <h5 class="card-header-title"><?php echo e(translate('Customer Table')); ?></h5>
                    <h5 class="card-header-title text-primary mx-1">(<?php echo e($customers->total()); ?>)</h5>
                </div>
                <div>
                    <form action="<?php echo e(url()->current()); ?>" method="GET">
                        <div class="input-group">
                            <input id="datatableSearch_" type="search" name="search"
                                   class="form-control"
                                   placeholder="<?php echo e(translate('Search')); ?>" aria-label="Search"
                                   value="<?php echo e($search); ?>" required autocomplete="off">
                            <div class="input-group-append">
                                <button type="submit" class="input-group-text"><i class="tio-search"></i>
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <!-- End Header -->

            <!-- Table -->
            <div class="table-responsive datatable-custom">
                <table
                    class="table table-hover table-borderless table-thead-bordered table-nowrap table-align-middle card-table"
                    style="width: 100%">
                    <thead class="thead-light">
                    <tr>
                        <th><?php echo e(translate('#')); ?></th>
                        <th style="width: 15%"><?php echo e(translate('image')); ?></th>
                        <th style="width: 30%"><?php echo e(translate('name')); ?></th>
                        <th><?php echo e(translate('phone')); ?></th>
                        <th><?php echo e(translate('email')); ?></th>
                        <th><?php echo e(translate('status')); ?></th>
                        <th><?php echo e(translate('action')); ?></th>
                    </tr>
                    </thead>

                    <tbody id="set-rows">
                    <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($customers->firstitem()+$key); ?></td>
                            <td>
                                <img class="rounded-circle" height="60px" width="60px" style="cursor: pointer"
                                     onclick="location.href='<?php echo e(route('admin.customer.view',[$customer['id']])); ?>'"
                                     onerror="this.src='<?php echo e(asset('public/assets/admin/img/160x160/img1.jpg')); ?>'"
                                     src="<?php echo e(asset('storage/app/public/customer')); ?>/<?php echo e($customer['image']); ?>">
                            </td>
                            <td>
                                <a class="d-block font-size-sm text-body"
                                   href="<?php echo e(route('admin.customer.view',[$customer['id']])); ?>">
                                    <?php echo e($customer['f_name'].' '.$customer['l_name']); ?>

                                </a>
                            </td>
                            <td>
                                <?php echo e($customer['phone']); ?>

                            </td>
                            <td>
                                <?php if(isset($customer['email'])): ?>
                                    <a href="mailto:<?php echo e($customer['email']); ?>" class="text-primary"><?php echo e($customer['email']); ?></a>
                                <?php else: ?>
                                    <span class="text-muted badge badge-danger text-dark"><?php echo e(translate('Email unavailable')); ?></span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <label class="toggle-switch d-flex align-items-center mb-3" for="welcome_status_<?php echo e($customer['id']); ?>">
                                    <input type="checkbox" name="welcome_status"
                                           class="toggle-switch-input"
                                           id="welcome_status_<?php echo e($customer['id']); ?>" <?php echo e($customer?($customer['is_active']==1?'checked':''):''); ?>

                                           onclick="location.href='<?php echo e(route('admin.customer.status',[$customer['id']])); ?>'">

                                    <span class="toggle-switch-label p-1">
                                        <span class="toggle-switch-indicator"></span>
                                    </span>
                                </label>
                            </td>
                            <td>
                                <a class="btn-sm btn-primary p-1 m-1"
                                   href="<?php echo e(route('admin.customer.view',[$customer['id']])); ?>">
                                    <i class="fa fa-eye pl-1" aria-hidden="true"></i>
                                </a>
                                <a class="btn-sm btn-secondary p-1 pr-2 m-1"
                                   href="<?php echo e(route('admin.customer.edit',[$customer['id']])); ?>">
                                    <i class="fa fa-pencil pl-1" aria-hidden="true"></i>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <!-- End Table -->

            <!-- Footer -->
            <div class="card-footer">
                <!-- Pagination -->
                <div class="row justify-content-center justify-content-sm-between align-items-sm-center">
                    <div class="col-sm-auto">
                        <div class="d-flex justify-content-center justify-content-sm-end">
                            <!-- Pagination -->
                            <?php echo $customers->links(); ?>

                            <nav id="datatablePagination" aria-label="Activity pagination"></nav>
                        </div>
                    </div>
                </div>
                <!-- End Pagination -->
            </div>
            <!-- End Footer -->
        </div>
        <!-- End Card -->
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script_2'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/czmcdcfryly0/public_html/rbpessacash.com/resources/views/admin-views/customer/list.blade.php ENDPATH**/ ?>