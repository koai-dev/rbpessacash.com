<?php $__env->startSection('title', translate('Details')); ?>

<?php $__env->startPush('css_or_js'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content container-fluid">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a
                        href="<?php echo e(route('admin.dashboard')); ?>"><?php echo e(translate('Dashboard')); ?></a>
                </li>
                <li class="breadcrumb-item"
                    aria-current="page"><?php echo e(translate('Details')); ?></li>
            </ol>
        </nav>

        <!-- Page Header -->
        <div class="page-header">
            <div class="flex-between row mx-1">
                <div>
                    <h1 class="page-header-title"></h1>
                </div>
            </div>
            <!-- Nav Scroller -->
            <div class="js-nav-scroller hs-nav-scroller-horizontal">
                <!-- Nav -->
                <ul class="nav nav-tabs page-header-tabs">
                    <li class="nav-item">
                        <a class="nav-link active"
                           <?php if(isset($user) && $user->type == 1): ?>
                           href="<?php echo e(route('admin.agent.view',[$user['id']])); ?>"
                           <?php elseif(isset($user) && $user->type == 2): ?>
                           href="<?php echo e(route('admin.customer.view',[$user['id']])); ?>"
                           <?php else: ?>
                           href="#"
                            <?php endif; ?>
                        ><?php echo e(translate('details')); ?></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link"
                           <?php if(isset($user) && $user->type == 1): ?>
                           href="<?php echo e(route('admin.agent.transaction',[$user['id']])); ?>"
                           <?php elseif(isset($user) && $user->type == 2): ?>
                           href="<?php echo e(route('admin.customer.transaction',[$user['id']])); ?>"
                           <?php else: ?>
                           href="#"
                            <?php endif; ?>
                        ><?php echo e(translate('Transactions')); ?></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link"
                           <?php if(isset($user) && $user->type == 1): ?>
                           href="<?php echo e(route('admin.agent.log',[$user['id']])); ?>"
                           <?php elseif(isset($user) && $user->type == 2): ?>
                           href="<?php echo e(route('admin.customer.log',[$user['id']])); ?>"
                           <?php else: ?>
                           href="#"
                            <?php endif; ?>
                        ><?php echo e(translate('Logs')); ?></a>
                    </li>
                </ul>
                <!-- End Nav -->
            </div>
            <!-- End Nav Scroller -->
        </div>
        <!-- End Page Header -->


        <div class="row my-3">
            <div class="col-6">
                <div class="card">
                    <div class="card-header text-capitalize"><?php echo e(translate('wallet')); ?><i style="font-size: 25px" class="tio-wallet"></i></div>
                    <div class="card-body">
                        <div class="card shadow h-100 for-card-body-3 badge-info"
                             style="background: #444941!important;">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div
                                            class=" font-weight-bold for-card-text text-uppercase mb-1"><?php echo e(translate('balance')); ?></div>
                                        <div
                                            class="for-card-count"><?php echo e($user->emoney['current_balance']??0); ?>

                                        </div>
                                    </div>
                                    <div class="col-auto for-margin">
                                        <i class="tio-money-vs"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-6">
                <div class="card">
                    <div class="card-header text-capitalize"><?php echo e(translate('Personal Info')); ?><i style="font-size: 25px" class="tio-info"></i></div>
                    <div class="card-body">
                        <div class="card-body"
                             style="text-align: <?php echo e(Session::get('direction') === "rtl" ? 'right' : 'left'); ?>;">
                            <div class="flex-start">
                                <div><h5><?php echo e(translate('name')); ?> : </h5></div>
                                <div class="mx-1"><span class="text-dark"><?php echo e($user['f_name']??''); ?> <?php echo e($user['l_name']??''); ?></span></div>
                            </div>
                            <div class="flex-start">
                                <div><h5><?php echo e(translate('Phone')); ?> : </h5></div>
                                <div class="mx-1"><span class="text-dark"><?php echo e($user['phone']??''); ?></span></div>
                            </div>
                            <?php if(isset($user['email'])): ?>
                                <div class="flex-start">
                                    <div><h5><?php echo e(translate('Email')); ?> : </h5></div>
                                    <div class="mx-1"><span class="text-dark"><?php echo e($user['email']); ?></span></div>
                                </div>
                            <?php endif; ?>
                            <?php if(isset($user['identification_type'])): ?>
                                <div class="flex-start">
                                    <div><h5><?php echo e(translate('identification_type')); ?> : </h5></div>
                                    <div class="mx-1"><span class="text-dark"><?php echo e(translate($user['identification_type'])); ?></span></div>
                                </div>
                            <?php endif; ?>
                            <?php if(isset($user['identification_number'])): ?>
                                <div class="flex-start">
                                    <div><h5><?php echo e(translate('identification_number')); ?> : </h5></div>
                                    <div class="mx-1"><span class="text-dark"><?php echo e($user['identification_number']); ?></span></div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script_2'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/czmcdcfryly0/public_html/rbpessacash.com/resources/views/admin-views/view/details.blade.php ENDPATH**/ ?>