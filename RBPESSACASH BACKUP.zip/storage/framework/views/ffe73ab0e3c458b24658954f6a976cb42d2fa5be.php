<?php $__env->startSection('title', translate('Agent Verification requests')); ?>

<?php $__env->startPush('css_or_js'); ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <script src="https://use.fontawesome.com/74721296a6.js"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content container-fluid">
        <!-- Page Header -->
        <div class="page-header">
            <div class="row align-items-center mb-3">
                <div class="col-sm flex-between">
                    <h1 class="page-header-title"><i
                            class="tio-user-add"></i> <?php echo e(translate('agents')); ?>

                    </h1>
                    <a href="<?php echo e(route('admin.agent.add')); ?>" class="btn btn-primary pull-right mr-1"><i
                            class="tio-add-circle"></i> <?php echo e(translate('Add')); ?> <?php echo e(translate('Agents')); ?>

                    </a>
                </div>
            </div>
            <!-- End Row -->
        </div>
        <!-- End Page Header -->

        <!-- Card -->
        <div class="card">
            <!-- Header -->
            <div class="card-header">
                <div class="flex-start">
                    <h5 class="card-header-title"><?php echo e(translate('Verification requests list')); ?></h5>
                    <h5 class="card-header-title text-primary mx-1">(<?php echo e($agents->total()); ?>)</h5>
                </div>
                <div>
                    <form action="<?php echo e(url()->current()); ?>" method="GET">
                        <div class="input-group">
                            <input id="datatableSearch_" type="search" name="search"
                                   class="form-control"
                                   placeholder="<?php echo e(translate('Search')); ?>" aria-label="Search"
                                   value="<?php echo e($search); ?>" required autocomplete="off">
                            <div class="input-group-append">
                                <button type="submit" class="input-group-text"><i class="tio-search"></i>
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <!-- End Header -->

            <!-- Table -->
            <div class="table-responsive datatable-custom">
                <table
                    class="table table-hover table-borderless table-thead-bordered table-nowrap table-align-middle card-table"
                    style="width: 100%">
                    <thead class="thead-light">
                    <tr>
                        <th><?php echo e(translate('#')); ?></th>
                        <th><?php echo e(translate('image')); ?></th>
                        <th><?php echo e(translate('name')); ?></th>
                        <th><?php echo e(translate('phone')); ?></th>
                        <th><?php echo e(translate('email')); ?></th>
                        <th><?php echo e(translate('Identification Type')); ?></th>
                        <th><?php echo e(translate('Identification Number')); ?></th>
                        <th style="width: 15%"><?php echo e(translate('Identification Image')); ?></th>
                        <th><?php echo e(translate('action')); ?></th>
                    </tr>
                    </thead>

                    <tbody id="set-rows">
                    <?php $__currentLoopData = $agents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$agent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($agents->firstitem()+$key); ?></td>
                            <td>
                                <img class="rounded-circle" height="60px" width="60px" style="cursor: pointer"
                                     onclick="location.href='<?php echo e(route('admin.agent.view',[$agent['id']])); ?>'"
                                     onerror="this.src='<?php echo e(asset('public/assets/admin/img/160x160/img1.jpg')); ?>'"
                                     src="<?php echo e(asset('storage/app/public/agent')); ?>/<?php echo e($agent['image']); ?>">
                            </td>
                            <td>
                                <a class="d-block font-size-sm text-body"
                                   href="<?php echo e(route('admin.agent.view',[$agent['id']])); ?>">
                                    <?php echo e($agent['f_name'].' '.$agent['l_name']); ?>

                                </a>
                            </td>
                            <td>
                                <?php echo e($agent['phone']); ?>

                            </td>
                            <td>
                                <?php if(isset($agent['email'])): ?>
                                    <a href="mailto:<?php echo e($agent['email']); ?>" class="text-primary"><?php echo e($agent['email']); ?></a>
                                <?php else: ?>
                                    <span class="text-muted badge badge-danger text-dark"><?php echo e(translate('Email unavailable')); ?></span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if(isset($agent['identification_type'])): ?>
                                    <?php echo e(translate($agent['identification_type'])); ?>

                                <?php else: ?>
                                    <span class="text-muted badge badge-danger text-dark"><?php echo e(translate('Type unavailable')); ?></span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if(isset($agent['identification_number'])): ?>
                                    <?php echo e($agent['identification_number']); ?>

                                <?php else: ?>
                                    <span class="text-muted badge badge-danger text-dark"><?php echo e(translate('Number unavailable')); ?></span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div data-toggle="" data-placement="top" title="<?php echo e(translate('click for bigger view')); ?>">
                                    <?php $__currentLoopData = json_decode($agent['identification_image'], true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $identification_image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <img class="" height="60px" width="120px" style="cursor: pointer; border-radius: 3px"
                                             onerror="this.src='<?php echo e(asset('public/assets/admin/img/900x400/img1.jpg')); ?>'"
                                             src="<?php echo e(asset('storage/app/public/user/identity')); ?>/<?php echo e($identification_image); ?>"
                                             onclick="show_modal('<?php echo e(asset('storage/app/public/user/identity')); ?>/<?php echo e($identification_image); ?>')">
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </td>
                            <td>
                                <?php if($agent['is_kyc_verified'] == 0): ?>
                                    <a class="btn-sm btn-success mr-1"
                                       href="<?php echo e(route('admin.agent.kyc_status_update',[$agent['id'], 1])); ?>">
                                       <i class="fa fa-check" aria-hidden="true"></i>
                                    </a>
                                    <a class="btn-sm btn-danger"
                                       href="<?php echo e(route('admin.agent.kyc_status_update',[$agent['id'], 2])); ?>">
                                       <i class="fa fa-times" aria-hidden="true"></i>
                                    </a>
                                <?php elseif($agent['is_kyc_verified'] == 2): ?>
                                    <span class="badge badge-danger"> <?php echo e(translate('Denied')); ?></span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <!-- End Table -->

            <!-- Modal -->
            <div class="modal fade bd-example-modal-lg" id="identification_image_view_modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-body p-0">
                            <div data-dismiss="modal">
                                <img src="<?php echo e(asset('public/assets/admin/img/900x400/img1.jpg')); ?>" alt=""
                                     class="" id="identification_image_element" style="width: 100%">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Modal End -->

            <!-- Footer -->
            <div class="card-footer">
                <!-- Pagination -->
                <div class="row justify-content-center justify-content-sm-between align-items-sm-center">
                    <div class="col-sm-auto">
                        <div class="d-flex justify-content-center justify-content-sm-end">
                            <!-- Pagination -->
                            <?php echo $agents->links(); ?>

                            <nav id="datatablePagination" aria-label="Activity pagination"></nav>
                        </div>
                    </div>
                </div>
                <!-- End Pagination -->
            </div>
            <!-- End Footer -->
        </div>
        <!-- End Card -->
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script_2'); ?>
    <script>
        function show_modal(image_location) {
            $('#identification_image_view_modal').modal('show');
            if(image_location != null || image_location !== '') {
                $('#identification_image_element').attr("src", image_location);
            }
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/czmcdcfryly0/public_html/rbpessacash.com/resources/views/admin-views/agent/kyc_list.blade.php ENDPATH**/ ?>