<?php $__env->startSection('title', translate('Add New Banner')); ?>

<?php $__env->startPush('css_or_js'); ?>
    <script src="https://use.fontawesome.com/74721296a6.js"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content container-fluid">
        <!-- Page Header -->
        <div class="page-header">
            <div class="row align-items-center">
                <div class="col-sm mb-2 mb-sm-0">
                    <h1 class="page-header-title"><i class="tio-image"></i> <?php echo e(translate('banner')); ?></h1>
                </div>
            </div>
        </div>

        <!-- End Page Header -->
        <div class="row gx-2 gx-lg-3">
            <div class="col-sm-12 col-lg-12 mb-3 mb-lg-2 card card-body mx-3">
                <form action="<?php echo e(route('admin.banner.store')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="form-group col-12">
                            <label class="input-label" for="exampleFormControlInput1"><?php echo e(translate('title')); ?></label>
                            <input type="text" name="title" class="form-control" placeholder="<?php echo e(translate('title')); ?>" required>
                        </div>
                        <div class="form-group col-12 col-md-6">
                            <label class="input-label" for="exampleFormControlInput1"><?php echo e(translate('URL')); ?></label>
                            <input type="text" name="url" class="form-control" placeholder="<?php echo e(translate('URL')); ?>" required>
                        </div>
                        <div class="form-group col-12 col-md-6">
                            <label class="input-label" for="exampleFormControlInput1"><?php echo e(translate('receiver')); ?></label>
                            <select name="receiver" class="form-control js-select2-custom" id="receiver" required>
                                <option value="all" selected><?php echo e(translate('All')); ?></option>
                                <option value="customers"><?php echo e(translate('Customers')); ?></option>
                                <option value="agents"><?php echo e(translate('Agents')); ?></option>
                            </select>
                        </div>
                        <div class="form-group col-12">
                            <label class="text-dark"><?php echo e(translate('image')); ?></label><small style="color: red; padding: 0 5px">* ( <?php echo e(translate('ratio')); ?> 3:1 )</small>
                            <div class="custom-file">
                                <input type="file" name="image" id="customFileEg1" class="custom-file-input"
                                       accept=".jpg, .png, .jpeg, .gif, .bmp, .tif, .tiff|image/*">
                                <label class="custom-file-label" for="customFileEg1"><?php echo e(translate('choose')); ?> <?php echo e(translate('file')); ?></label>
                            </div>
                            <div class="text-center mt-4">
                                <img style="width: 30%;border: 1px solid; border-radius: 10px;" id="viewer"
                                     src="<?php echo e(asset('public/assets/admin/img/900x400/img1.jpg')); ?>" alt="image"/>
                            </div>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary mt-4"><?php echo e(translate('Add Banner')); ?></button>
                </form>
            </div>

            <div class="col-sm-12 col-lg-12 mb-3 mb-lg-2 mt-2">
                <div class="card">
                    <div class="card-header flex-between">
                        <div class="flex-start">
                            <h5 class="card-header-title"><?php echo e(translate('Banner Table')); ?></h5>
                            <h5 class="card-header-title text-primary mx-1">(<?php echo e($banners->total()); ?>)</h5>
                        </div>
                        <div>
                            <form action="<?php echo e(url()->current()); ?>" method="GET">
                                <div class="input-group">
                                    <input id="datatableSearch_" type="search" name="search"
                                           class="form-control"
                                           placeholder="<?php echo e(translate('Search')); ?>" aria-label="Search"
                                           value="<?php echo e($search); ?>" required autocomplete="off">
                                    <div class="input-group-append">
                                        <button type="submit" class="input-group-text"><i class="tio-search"></i>
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <!-- Table -->
                    <div class="table-responsive datatable-custom">
                        <table class="table table-borderless table-thead-bordered table-nowrap table-align-middle card-table">
                            <thead class="thead-light">
                            <tr>
                                <th><?php echo e(translate('#')); ?></th>
                                <th style="width: 50%"><?php echo e(translate('title')); ?></th>
                                <th><?php echo e(translate('URL')); ?></th>
                                <th><?php echo e(translate('image')); ?></th>
                                <th><?php echo e(translate('status')); ?></th>
                                <th><?php echo e(translate('receiver')); ?></th>
                                <th style="width: 10%"><?php echo e(translate('action')); ?></th>
                            </tr>
                            </thead>

                            <tbody>
                            <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($banners->firstitem()+$key); ?></td>
                                    <td>
                                    <span class="d-block font-size-sm text-body">
                                        <?php echo e(substr($banner['title'],0,25)); ?> <?php echo e(strlen($banner['title'])>25?'...':''); ?>

                                    </span>
                                    </td>
                                    <td>
                                        <a class="text-dark" href="<?php echo e($banner['url']); ?>"><?php echo e(substr($banner['url'],0,25)); ?> <?php echo e(strlen($banner['url'])>25?'...':''); ?></a>
                                    </td>
                                    <td>
                                        <?php if($banner['image']!=null): ?>
                                            <img style="height: 75px" class="shadow-image"
                                                 src="<?php echo e(asset('storage/app/public/banner')); ?>/<?php echo e($banner['image']); ?>"
                                                 onerror="this.src='<?php echo e(asset('public/assets/admin/img/400x400/img2.jpg')); ?>'">
                                        <?php else: ?>
                                            <label class="badge badge-soft-warning"><?php echo e(translate('No Image')); ?></label>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <label class="toggle-switch d-flex align-items-center mb-3" for="welcome_status_<?php echo e($banner['id']); ?>">
                                            <input type="checkbox" name="welcome_status"
                                                   class="toggle-switch-input"
                                                   id="welcome_status_<?php echo e($banner['id']); ?>" <?php echo e($banner?($banner['status']==1?'checked':''):''); ?>

                                                   onclick="location.href='<?php echo e(route('admin.banner.status',[$banner['id']])); ?>'">

                                            <span class="toggle-switch-label p-1">
                                                <span class="toggle-switch-indicator"></span>
                                            </span>
                                        </label>
                                    </td>
                                    <td class="text-center">
                                        <?php if(isset($banner['receiver'])): ?>
                                            <span class="badge badge-light text-muted" style="cursor: default"><?php echo e(translate($banner['receiver'] ?? '')); ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <a class="btn-sm btn-primary p-1 pr-2 m-1"
                                           href="<?php echo e(route('admin.banner.edit',[$banner['id']])); ?>">
                                            <i class="fa fa-pencil pl-1" aria-hidden="true"></i>
                                        </a>
                                        <a class="btn-sm btn-secondary p-1 pr-2 m-1"
                                           href="<?php echo e(route('admin.banner.delete',[$banner['id']])); ?>">
                                            <i class="fa fa-trash-o pl-1" aria-hidden="true"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                        <hr>
                        <table>
                            <tfoot>
                            <?php echo $banners->links(); ?>

                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
            <!-- End Table -->
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script_2'); ?>
    <script>
        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#viewer').attr('src', e.target.result);
                }

                reader.readAsDataURL(input.files[0]);
            }
        }

        $("#customFileEg1").change(function () {
            readURL(this);
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/czmcdcfryly0/public_html/rbpessacash.com/resources/views/admin-views/banner/index.blade.php ENDPATH**/ ?>